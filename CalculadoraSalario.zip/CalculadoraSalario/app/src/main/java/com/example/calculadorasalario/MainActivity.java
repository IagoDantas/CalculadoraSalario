package com.example.calculadorasalario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private Button btnNovoSalario;
    private RadioGroup rdgGroupPercent;
    private RadioButton rdbQuarentaPercent,rdbCinquentaPercent, rdbSessentaPercent;
    private EditText edtSalario;
    private TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnNovoSalario = findViewById(R.id.btnNovoSalario);
        rdbCinquentaPercent = findViewById(R.id.rdbCinquentaPercent);
        rdbQuarentaPercent = findViewById(R.id.rdbQuarentaPercent);
        rdbSessentaPercent = findViewById(R.id.rdbSessentaPercent);
        edtSalario = findViewById(R.id.edtSalario);
        txtResultado = findViewById(R.id.txtResultado);
    }

    public void calcularSalario(View v) {
        double salario, salarioTotal;

        salario = Double.parseDouble(edtSalario.getText().toString());

        if(rdbQuarentaPercent.isChecked())
        {
            salarioTotal = salario * 1.4;
            txtResultado.setText("O novo salário é: R$ " + salarioTotal);

        }
        else if(rdbCinquentaPercent.isChecked())
        {
            salarioTotal = salario * 1.5;
            txtResultado.setText("O novo salário é: R$ " + salarioTotal);
        }
        else if(rdbSessentaPercent.isChecked())
        {
            salarioTotal = salario * 1.6;
            txtResultado.setText("O novo salário é: R$ " + salarioTotal);
        }


    }
}